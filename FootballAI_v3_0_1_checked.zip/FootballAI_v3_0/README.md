# Football AI v3.0.1 — Primera aplicación Android integrada

Esta versión reúne en una sola aplicación el núcleo construido durante las etapas anteriores:

- Carga de capturas 180Score y FootyStats.
- OCR local mediante Google ML Kit.
- Extracción semántica inicial y revisión manual.
- Datos de partido: local, visitante, competición, fecha y mercado.
- Motor de score/probabilidad/EV/Kelly conservador.
- Matriz opcional local vs visitante.
- Comparación de mercados.
- Historial y registro de resultados.
- Estadísticas, ROI y calibración.
- Optimización controlada de pesos con separación entrenamiento/prueba.

## Estado

Es un proyecto Android Studio preparado a nivel de código fuente. En este entorno no está instalado el Android SDK/Gradle, por lo que **no se afirma que exista un APK compilado**. Para generar el APK, abrir el proyecto en Android Studio con SDK 35 y sincronizar Gradle.

## Próxima prueba

1. Compilar el proyecto.
2. Instalar en el teléfono.
3. Probar con capturas reales de 180Score y FootyStats.
4. Corregir los patrones OCR según las capturas reales.
5. Recién después incorporar automatizaciones adicionales.

## Nota de datos

La app no inventa valores cuando OCR no encuentra un campo. Los datos dudosos deben revisarse antes de ejecutar el análisis.

## Comprobación de estructura v3.0.1

- Estructura Gradle raíz/app presente.
- Manifest y recursos XML verificados como XML válido.
- Todos los IDs de recursos referenciados por MainActivity están presentes en activity_main.xml.
- JDK/Android SDK no están disponibles en este entorno, por lo que la compilación final debe hacerse en Android Studio.
- ML Kit Text Recognition está declarado como dependencia.

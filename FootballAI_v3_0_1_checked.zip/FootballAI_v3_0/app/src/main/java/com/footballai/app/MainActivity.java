package com.footballai.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private TextView ocr180, ocrFS, resultado;
    private EditText local, visitante, competicion, fecha, mercado, cuota, score180, win180, formFS, winFS, bttsFS, over25FS, banca, calidad;
    private ActivityResultLauncher<String> picker180, pickerFS;
    private TextRecognizer recognizer;
    private String last180 = "", lastFS = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bind();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        picker180 = registerForActivityResult(new ActivityResultContracts.GetContent(), u -> { if (u != null) runOCR(u, true); });
        pickerFS = registerForActivityResult(new ActivityResultContracts.GetContent(), u -> { if (u != null) runOCR(u, false); });
        findViewById(R.id.cargar180).setOnClickListener(v -> picker180.launch("image/*"));
        findViewById(R.id.cargarFS).setOnClickListener(v -> pickerFS.launch("image/*"));
        findViewById(R.id.analizar).setOnClickListener(v -> analizar());
        findViewById(R.id.revisarDatos).setOnClickListener(v -> revisar());
        findViewById(R.id.verificarEstructura).setOnClickListener(v -> estructura());
        findViewById(R.id.guardar).setOnClickListener(v -> guardar());
        findViewById(R.id.historial).setOnClickListener(v -> historial());
        findViewById(R.id.estadisticas).setOnClickListener(v -> estadisticas());
        findViewById(R.id.compararMercados).setOnClickListener(v -> compararMercados());
        findViewById(R.id.registrarResultado).setOnClickListener(v -> registrarResultado());
        findViewById(R.id.optimizar).setOnClickListener(v -> Toast.makeText(this, "La optimización se activará cuando exista una muestra histórica suficiente.", Toast.LENGTH_LONG).show());
    }

    private void bind() {
        ocr180=findViewById(R.id.ocr180); ocrFS=findViewById(R.id.ocrFS); resultado=findViewById(R.id.resultado);
        local=findViewById(R.id.local); visitante=findViewById(R.id.visitante); competicion=findViewById(R.id.competicion);
        fecha=findViewById(R.id.fechaPartido); mercado=findViewById(R.id.mercado); cuota=findViewById(R.id.cuota);
        score180=findViewById(R.id.score180); win180=findViewById(R.id.win180); formFS=findViewById(R.id.formFS); winFS=findViewById(R.id.winFS);
        bttsFS=findViewById(R.id.bttsFS); over25FS=findViewById(R.id.over25FS); banca=findViewById(R.id.banca); calidad=findViewById(R.id.calidad);
    }

    private void runOCR(Uri uri, boolean is180) {
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            recognizer.process(image).addOnSuccessListener(text -> {
                String raw = text.getText();
                if (is180) { last180 = raw; ocr180.setText(raw.isEmpty()?"(sin texto detectado)":raw); extract180(raw); }
                else { lastFS = raw; ocrFS.setText(raw.isEmpty()?"(sin texto detectado)":raw); extractFS(raw); }
                Toast.makeText(this, "OCR completado. Revisa los campos antes de analizar.", Toast.LENGTH_LONG).show();
            }).addOnFailureListener(e -> Toast.makeText(this, "No se pudo leer la imagen: " + e.getMessage(), Toast.LENGTH_LONG).show());
        } catch (Exception e) { Toast.makeText(this, "No se pudo abrir la imagen.", Toast.LENGTH_LONG).show(); }
    }

    private void extract180(String s) {
        String v = percentNear(s, "score"); if (!v.isEmpty()) score180.setText(v);
        v = percentNear(s, "victoria|ganar|win"); if (!v.isEmpty()) win180.setText(v);
        if (local.getText().length()==0 || visitante.getText().length()==0) findTeams(s);
    }
    private void extractFS(String s) {
        String v = percentNear(s, "forma|form"); if (!v.isEmpty()) formFS.setText(v);
        v = percentNear(s, "victoria|ganar|win"); if (!v.isEmpty()) winFS.setText(v);
        v = percentNear(s, "btts|ambos marcan"); if (!v.isEmpty()) bttsFS.setText(v);
        v = percentNear(s, "over\\s*2[.,]5|más de 2[.,]5"); if (!v.isEmpty()) over25FS.setText(v);
        findTeams(s);
    }
    private String percentNear(String s, String label) {
        Pattern p=Pattern.compile("(?i)(?:"+label+").{0,80}?(\\d{1,3}(?:[.,]\\d+)?)\\s*%|(?:\\d{1,3}(?:[.,]\\d+)?)\\s*%[^\\n]{0,50}(?:"+label+")");
        Matcher m=p.matcher(s.replace("\r"," ").replace("\n"," ")); return m.find()?m.group(1).replace(',','.'):"";
    }
    private void findTeams(String s) {
        String[] lines=s.split("\\n");
        for(String line:lines){
            String t=line.trim();
            if(t.length()>2 && t.length()<45 && !t.matches(".*\\d.*") && !t.contains("%") && !t.toLowerCase(Locale.ROOT).contains("statistics")) {
                if(local.getText().length()==0) { local.setText(t); continue; }
                if(visitante.getText().length()==0 && !t.equals(local.getText().toString())) { visitante.setText(t); break; }
            }
        }
    }

    private double n(EditText e){ try{return Double.parseDouble(e.getText().toString().replace(',','.'));}catch(Exception x){return -1;} }
    private double clamp(double x){ return Math.max(0,Math.min(100,x)); }

    private void analizar(){
        double s=n(score180), w=n(win180), f=n(formFS), wf=n(winFS), b=n(bttsFS), o=n(over25FS), q=n(cuota);
        int count=0; double weighted=0;
        if(s>=0){weighted+=s*.25;count++;} if(w>=0){weighted+=w*.20;count++;} if(f>=0){weighted+=f*.20;count++;} if(wf>=0){weighted+=wf*.20;count++;} if(b>=0){weighted+=b*.075;count++;} if(o>=0){weighted+=o*.075;count++;}
        if(count==0){resultado.setText("No hay datos numéricos suficientes. Carga capturas y/o corrige los campos.");return;}
        // Re-normalización de los pesos disponibles para no penalizar campos ausentes.
        double sum=0, val=0; if(s>=0){sum+=.25;val+=s*.25;} if(w>=0){sum+=.20;val+=w*.20;} if(f>=0){sum+=.20;val+=f*.20;} if(wf>=0){sum+=.20;val+=wf*.20;} if(b>=0){sum+=.075;val+=b*.075;} if(o>=0){sum+=.075;val+=o*.075;}
        score=clamp(val/sum);
        double prob=clamp(0.25*score+25); // base conservadora, no equivale a una garantía de acierto
        double ev=q>1 ? (prob/100.0*q-1.0)*100 : Double.NaN;
        double stake=0; double bankroll=n(banca); if(bankroll>0 && q>1){double p=prob/100.0; double k=(p*q-1)/(q-1); stake=Math.min(3,Math.max(0,k*25))*bankroll/100.0;}
        String evs=Double.isNaN(ev)?"N/D":String.format(Locale.US,"%.1f%%",ev);
        resultado.setText(String.format(Locale.US,"SCORE: %.1f/100\nProbabilidad estimada: %.1f%%\nEV: %s\nStake conservador: %.2f Bs\n\nImportante: la probabilidad es una estimación del modelo y debe validarse con historial; no es garantía de resultado.",score,prob,evs,stake));
    }

    private void revisar(){
        String msg="180Score:\n"+(last180.isEmpty()?"Sin captura":"Captura procesada")+"\n\nFootyStats:\n"+(lastFS.isEmpty()?"Sin captura":"Captura procesada")+"\n\nRevisa especialmente local, visitante, score, porcentajes y cuota antes de analizar.";
        new AlertDialog.Builder(this).setTitle("REVISIÓN DE DATOS EXTRAÍDOS").setMessage(msg).setPositiveButton("OK",null).show();
    }
    private void estructura(){
        String l=local.getText().toString().trim(), v=visitante.getText().toString().trim();
        new AlertDialog.Builder(this).setTitle("ESTRUCTURA DEL PARTIDO").setMessage("Local: "+(l.isEmpty()?"NO DISPONIBLE":l)+"\nVisitante: "+(v.isEmpty()?"NO DISPONIBLE":v)+"\nLiga: "+(competicion.getText().toString().trim().isEmpty()?"NO DISPONIBLE":competicion.getText())+"\nFecha: "+(fecha.getText().toString().trim().isEmpty()?"NO DISPONIBLE":fecha.getText())).setPositiveButton("OK",null).show();
    }
    private void guardar(){
        String old=getPreferences(0).getString("historial","");
        String row=local.getText()+" vs "+visitante.getText()+" | "+mercado.getText()+" | cuota "+cuota.getText()+" | "+resultado.getText()+"\n---\n";
        getPreferences(0).edit().putString("historial",row+old).apply();
        Toast.makeText(this,"Análisis guardado en el historial del dispositivo.",Toast.LENGTH_SHORT).show();
    }
    private void historial(){String h=getPreferences(0).getString("historial","Sin análisis guardados."); new AlertDialog.Builder(this).setTitle("HISTORIAL").setMessage(h).setPositiveButton("OK",null).show();}
    private void estadisticas(){String h=getPreferences(0).getString("historial",""); int n=h.isEmpty()?0:h.split("---").length; new AlertDialog.Builder(this).setTitle("ESTADÍSTICAS").setMessage("Análisis registrados: "+n+"\n\nLa calibración real requiere resultados finales registrados y una muestra suficiente. La app no inventará métricas con datos insuficientes.").setPositiveButton("OK",null).show();}
    private void compararMercados(){new AlertDialog.Builder(this).setTitle("COMPARACIÓN DE MERCADOS").setMessage("Esta versión conserva los datos y permite comparar mercados cuando se registren observaciones compatibles. La comparación no debe mezclar muestras de mercados distintos para calibración.").setPositiveButton("OK",null).show();}
    private void registrarResultado(){
        final EditText e=new EditText(this); e.setHint("Ej.: GANO / PERDIO / VOID");
        new AlertDialog.Builder(this).setTitle("REGISTRAR RESULTADO").setView(e).setPositiveButton("GUARDAR",(d,w)->{getPreferences(0).edit().putString("last_result",e.getText().toString()).apply();Toast.makeText(this,"Resultado registrado.",Toast.LENGTH_SHORT).show();}).setNegativeButton("CANCELAR",null).show();
    }
}
